export { prisma, default } from './prisma';
export * from './queries';
